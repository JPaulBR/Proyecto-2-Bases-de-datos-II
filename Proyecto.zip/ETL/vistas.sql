create view Ubicaciones --Vista de las ubicaciones del cliente
as
	select ab.CityID,ab.CityName,ar.StateProvinceName,CountryName
	from Application.Cities ab
	inner join Application.StateProvinces ar on ab.StateProvinceID = ar.StateProvinceID
	inner join Application.Countries az on ar.CountryID = az.CountryID
go

create view TablaHechos2 --Tabla de hechos 
as
	select ab.InvoiceID,ab.BillToCustomerID,ab.SalespersonPersonID,ac.CityID ,ab.InvoiceDate,az.StockItemID,ar.Description,ar.Quantity,ar.UnitPrice,ar.TaxRate
	from Sales.Invoices ab
	inner join Sales.InvoiceLines ar on ab.InvoiceID = ar.InvoiceID
	inner join Warehouse.StockItems az on ar.StockItemID = az.StockItemID
	inner join Sales.Customers av on ab.BillToCustomerID = av.CustomerID
	inner join Ubicaciones ac on av.DeliveryCityID = ac.CityID 
go

create view Clientes
as
	select CustomerID,CustomerName,DeliveryCityID,PhoneNumber,FaxNumber
	from Sales.Customers
go

create view Vendedores
as
	select PersonID,FullName,PhoneNumber,FaxNumber,EmailAddress
	from Application.People
go

create view Productos
as
	select ar.StockItemID, ar.StockItemName, ab.PackageTypeName, ar.UnitPrice
	from Warehouse.StockItems ar
	inner join Warehouse.PackageTypes ab on ar.UnitPackageID = ab.PackageTypeID